﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Header.cs
/// Holds header of invoices
/// </summary>
namespace COMP2614Assign03
{
    class Header
    {
        private string invoiceNumber;
        private DateTime date;
        private DateTime discountDate;
        private int discountTerm;

        /// <summary>
        /// default ctor
        /// </summary>
        public Header()
        {

        }

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="invoiceNumber">to hold invoiceNumber</param>
        /// <param name="invoiceDate">to hold date and number of discountDates</param>
        /// <param name="discountTerm">to hold discountTerm</param>
        public Header(string invoiceNumber, string invoiceDate, int discountTerm)
        {
            InvoiceNumber = invoiceNumber;
            date = new DateTime(int.Parse(invoiceDate.Split('/')[0]), int.Parse(invoiceDate.Split('/')[1]), int.Parse(invoiceDate.Split('/')[2]));
            discountDate = date.AddDays(discountTerm % 100);
            DiscountTerm = discountTerm;
        }

        /// <summary>
        /// InvoiceNumber Property Method
        /// </summary>
        public string InvoiceNumber
        {
            get { return invoiceNumber; }
            set { invoiceNumber = value; }
        }

        /// <summary>
        /// Date Property Method
        /// </summary>
        public DateTime Date
        {
            get { return date; }
            set { date = value; }
        }

        /// <summary>
        /// DiscountDate Property Method
        /// </summary>
        public DateTime DiscountDate
        {
            get { return discountDate; }
            set { discountDate = value; }
        }

        /// <summary>
        /// DiscountTerm Property Method
        /// </summary>
        public int DiscountTerm
        {
            get { return discountTerm; }
            set { discountTerm = value; }
        }

    }
}
