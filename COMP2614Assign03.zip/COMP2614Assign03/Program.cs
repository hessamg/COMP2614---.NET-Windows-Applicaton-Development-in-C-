﻿// Assignment 3 Solution
// Hessam Ganjian
// 06 Oct 2017
// Program.cs

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

/// <summary>
/// This program reads a file containing invoice data and stores the data in a collection of data classes
/// </summary>
namespace COMP2614Assign03
{
    class Program
    {
        static void Main(string[] args)
        {
            string path;

            if (args.Length > 0)
            {
                path = args[0];
            }
            else
            {
                Console.WriteLine("Usage: COMP2614Exercise03 invoicedata.txt");
                return;
            }
            // This object lets you read from a file.
            StreamReader streamReader = null;


            if (File.Exists(path))
            {
                string lineData;
                string[] lineElements;
                Header header;
                List<Product> products;
                List<Invoice> invoices = new List<Invoice>();
               
               
                Console.WriteLine(new string('-', 61));
                Console.WriteLine("Invoice Listing");
                Console.WriteLine(new string('-', 61));
                Console.WriteLine();
                // Read entire file line-by-line and display to the screen.
                try
                {
                    // Attempt to open the file.  It will throw
                    // an exception if there is a problem opening it, 
                    // hence the try/catch block.
                    streamReader = new StreamReader(path);

                    // Peek returns the ASCII value of the next character in 
                    // the file *without* advancing the file position.
                    // 
                    // This lets us see whether we've reached the end of the
                    // file yet.
                    while (streamReader.Peek() > 0)
                    {
                        header = new Header();
                        products = new List<Product>();
                        // Read a line at a time, printing it to the screen.
                        lineData = streamReader.ReadLine();
                        lineElements = lineData.Split('|');

                        //int discountDate = int.Parse(invoiceDate) + (discountTerm % 100);
                        for (int i = 0; i < lineElements.Length; i++)
                        {
                            
                            if (i == 0) //this is the header
                            {
                                header = new Header(lineElements[i].Split(':')[0], lineElements[i].Split(':')[1], int.Parse(lineElements[i].Split(':')[2]));
                            }
                            else    //these are the product details 
                            {
                                products.Add(new Product(lineElements[i]));
                            }
                        }

                        invoices.Add(new Invoice(header, products));
                     
                    }
                    
                    ConsolePrinter.PrintInvoices(invoices);

                }

                // this block will execute if an exception is thrown in the try block
                catch (Exception ex)
                {
                    Console.WriteLine("\n{0}\n", ex.Message);
                }

                // this block always executes - used for resource cleanup.
                finally
                {
                    if (streamReader != null) // always test for null
                    {                         //  StreamReader instantiation might have failed
                        streamReader.Close(); // Will throw an exception if streamReader is null
                    }                         // VERY bad practice to throw an exception in a
                }                             //  catch or finally block
            }
            else
            {
                Console.WriteLine("\nFile not found.\n");
            }
        }
    }
}
