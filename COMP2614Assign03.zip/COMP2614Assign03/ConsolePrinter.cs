﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// ConsolePrinter.cs
/// Displays the data from the collection to the console
/// </summary>
namespace COMP2614Assign03
{
    class ConsolePrinter
    {
        public static void PrintInvoices(List<Invoice> invoices)
        {
            for (int i = 0; i < invoices.Count; i++)
            {
                Console.WriteLine($"Invoice Number:{"",1}{invoices[i].Header.InvoiceNumber}");
                Console.WriteLine($"Invoice Date:{"",3}{invoices[i].Header.Date.ToString("MMM d, yyyy")}");

                //if there is no discount, don't show the Discount Date and Terms
                if (invoices[i].Header.DiscountTerm != 0)
                {
                    Console.WriteLine($"Discount Date:{"",2}{invoices[i].Header.DiscountDate.ToString("MMM d, yyyy")}");
                    Console.WriteLine($"Terms:{"",10}{invoices[i].Header.DiscountTerm / 100,0:N}% {invoices[i].Header.DiscountTerm % 100} days ADI");
                }
                Console.WriteLine(new string('-', 61));
                Console.WriteLine($"Qty SKU{"Description",20}{"Price",20} PST{"Ext",10}");
                Console.WriteLine(new string('-', 61));

                for (int j = 0; j < invoices[i].Products.Count; j++)
                {
                    Console.WriteLine($"{invoices[i].Products[j].Quantity,3} {invoices[i].Products[j].SKU,-8}{"",4}{invoices[i].Products[j].Description,-20}{invoices[i].Products[j].Price,11}  {invoices[i].Products[j].CheckPST}{invoices[i].Products[j].ExtendedPrice,11:N}");
                }

                Console.WriteLine(new string('-', 61));
                Console.WriteLine($"{"Subtotal:",25} {invoices[i].Subtotal,35:N}");
                Console.WriteLine($"{"GST:",20} {invoices[i].GST,40:N}");

                //if invoices pst is 0 dont show PST
                if (invoices[i].PST != 0m)
                {
                    Console.WriteLine($"{"PST:",20} {invoices[i].PST,40:N}");
                }
                Console.WriteLine(new string('-', 61));

                Console.WriteLine($"{"Total:",22} {invoices[i].Total,38:N}");
                Console.WriteLine();
                Console.WriteLine($"{"Discount:",25} {invoices[i].TotalDiscount,35:N}");
                Console.WriteLine();
                Console.WriteLine();
            }
        }
    }
}
