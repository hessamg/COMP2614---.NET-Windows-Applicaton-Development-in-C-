﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Invoices.cs
/// Holds invoice
/// </summary>

namespace COMP2614Assign03
{
    class Invoice
    {
        private Header header;
        private List<Product> products;


        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="header">to hold header of invoice</param>
        /// <param name="products">to hold all the products as a list of products</param>
        public Invoice(Header header, List<Product> products)
        {
            Header = header;
            Products = products;
        }

        /// <summary>
        /// Header Property Method
        /// </summary>
        public Header Header
        {
            get { return header; }
            set { header = value; }
        }

        /// <summary>
        /// Products Property Method
        /// </summary>
        public List<Product> Products
        {
            get { return products; }
            set { products = value; }
        }

        /// <summary>
        /// Calculates Discount
        /// </summary>
        public decimal Discount
        {
            get
            {
                return (header.DiscountTerm / 100) / 100m;
            }
        }

        /// <summary>
        /// Calculates Subtotal
        /// </summary>
        public decimal Subtotal
        {
            get
            {
                decimal subtotal = 0m;
                for (int i = 0; i < Products.Count; i++)
                {
                    subtotal += products[i].ExtendedPrice;
                }
                return subtotal;
            }
        }

        /// <summary>
        /// Calculates GST
        /// </summary>
        public decimal GST
        {
            get
            {
                decimal gst = 0m;
                for (int i = 0; i < Products.Count; i++)
                {
                    gst += products[i].ExtendedPrice * 0.05m;
                }
                return gst;
            }
        }

        /// <summary>
        /// Calculates PST
        /// </summary>
        public decimal PST
        {
            get
            {
                decimal pst = 0m;

                for (int i = 0; i < Products.Count; i++)
                {
                    if (products[i].Taxable)
                    {
                        pst += products[i].ExtendedPrice * 0.07m;
                    }
                }

                return pst;
            }
        }

        /// <summary>
        /// Calculates Total
        /// </summary>
        public decimal Total
        {
            get
            {
                return Subtotal + GST + PST;
            }
        }

        /// <summary>
        /// Calculates TotalDiscount
        /// </summary>
        public decimal TotalDiscount
        {
            get
            {
                return Discount * Total;
            }
        }

    }
}
