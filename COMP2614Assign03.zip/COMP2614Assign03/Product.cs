﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Product
/// Holds Product
/// </summary>
namespace COMP2614Assign03
{
    class Product
    {
        private int quantity;
        private string sku;
        private string description;
        private decimal price;
        private char checkPST;
        private decimal extendedPrice;
        private bool taxable;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="item">to hold item full decription as string</param>
        public Product(string item)
        {
            Quantity = int.Parse(item.Split(':')[0]);
            SKU = item.Split(':')[1];
            Description = item.Split(':')[2];
            Price = decimal.Parse(item.Split(':')[3]);
            CheckPST = char.Parse(item.Split(':')[4]);
            ExtendedPrice = Quantity * Price;
            if(CheckPST == 'Y')
            {
                Taxable = true;
            }
            else
            {
                Taxable = false;
            }
        }

        /// <summary>
        /// Quantity Property Method
        /// </summary>
        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }

        /// <summary>
        /// SKU Property Method
        /// </summary>
        public string SKU
        {
            get { return sku; }
            set { sku = value; }
        }

        /// <summary>
        /// Description Property Method
        /// </summary>
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        /// <summary>
        /// Price Property Method
        /// </summary>
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        /// <summary>
        /// checkPST Property Method
        /// </summary>
        public char CheckPST
        {
            get { return checkPST; }
            set { checkPST = value; }
        }

        /// <summary>
        /// ExtendedPrice Property Method
        /// </summary>
        public decimal ExtendedPrice
        {
            get { return extendedPrice; }
            set { extendedPrice = value; }
        }

        /// <summary>
        /// Taxable Property Method
        /// </summary>
        public bool Taxable
        {
            get { return taxable; }
            set { taxable = value; }
        }

    }
}
