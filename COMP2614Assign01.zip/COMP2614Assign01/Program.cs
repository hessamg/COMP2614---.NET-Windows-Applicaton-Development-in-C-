﻿// Assignment 1 Solution
// Hessam Ganjian
// 20 Sep 2017

// This program lists all the even numbers from 0 to TOP_EVEN_NUMBER with their squres and cubes and the sum of each column

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace COMP2614Assign01
{
    class Program
    {
        static void Main(string[] args)
        {
            const int TOP_EVEN_NUMBER = 20;
            int sumOfEvenNumbers = 0;
            int sumOfSquares = 0;
            int sumOfCubes = 0;
            Console.WriteLine("{0,8} {1,8} {2,8}", "number","square","cube");   //outputs the results with the correct allignment and formating
            Console.WriteLine("--------------------------");
            displayEvenNumbers(TOP_EVEN_NUMBER, ref sumOfEvenNumbers, ref sumOfSquares, ref sumOfCubes);
            Console.WriteLine("--------------------------");
            Console.WriteLine("{0,8:n0} {1,8:n0} {2,8:n0}", sumOfEvenNumbers, sumOfSquares, sumOfCubes);              
        }

        
        private static void displayEvenNumbers(int top, ref int sumEvens, ref int sumSqrs, ref int sumCubes)
        {
            for (int numbers = 0; numbers <= top; numbers += 2)
            {
                sumEvens += numbers;
                sumSqrs += calculateSquares(ref numbers);
                sumCubes += calculateCubes(ref numbers);
                Console.WriteLine("{0,8:n0} {1,8:n0} {2,8:n0}", numbers, calculateSquares(ref numbers), calculateCubes(ref numbers));
            }
        }

        private static int calculateSquares(ref int number)
        {
            return number * number;
        }

        private static int calculateCubes(ref int number)
        {
            return number * number * number;
        }
    }
}
