﻿// Assignment 2 Solution
// Hessam Ganjian
// Class Program.cs
// 27 Sep 2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP2614Assign02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Contact Information");
            Console.WriteLine(new string('-', 20));

            Console.Write("{0,-13}", "Firstname:");
            string firstName = Console.ReadLine();

            Console.Write("{0,-13}", "LastName:");
            string lastName = Console.ReadLine();

            Console.Write("{0,-13}", "Address:");
            string address = Console.ReadLine();

            Console.Write("{0,-13}", "City:");
            string city = Console.ReadLine();

            Console.Write("{0,-13}", "Province:");
            string province = Console.ReadLine();

            Console.Write("{0,-13}", "PostalCode:");
            string postalCode = Console.ReadLine();

            Console.WriteLine();

            Contact contact1 = new Contact();
            contact1.FirstName = firstName;
            contact1.LastName = lastName;
            contact1.Address = address;
            contact1.City = city;
            contact1.Province = province;
            contact1.PostalCode = postalCode;

            Contact contact2 = new Contact(firstName, lastName, address, city, province, postalCode);

            Contact contact3 = new Contact { FirstName = firstName, LastName = lastName, Address = address, City = city, Province = province, PostalCode = postalCode };
            Contact[] contacts = { contact1, contact2, contact3 };

            ConsolePrinter.print(contacts);
        }
    }
}
