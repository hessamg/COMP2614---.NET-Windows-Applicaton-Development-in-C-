﻿// Assignment 2 Solution
// Hessam Ganjian
// Class ConsolePrinter.cs
// 27 Sep 2017

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP2614Assign02
{
    class ConsolePrinter
    {
        public static void print(Contact[] contacts)
        {
            Console.WriteLine("Contacts: ");
            Console.WriteLine(new string('-', 20));

            foreach (Contact contact in contacts)
            {
                //output the first letter of firstName and the first letter of lastName in uppercase letter
                Console.WriteLine("{0}{1} {2}{3}"
                    , contact.FirstName.Substring(0,1).ToUpper()
                    , contact.FirstName.Substring(1)
                    , contact.LastName.Substring(0, 1).ToUpper()
                    , contact.LastName.Substring(1));

                Console.WriteLine("{0}", contact.Address);

                //output the first letter of city and province and postalCode in uppercase letter
                Console.WriteLine("{0}{1} {2}  {3}"
                    , contact.City.Substring(0, 1).ToUpper()
                    , contact.City.Substring(1)
                    , contact.Province.ToUpper()
                    , contact.PostalCode.ToUpper());

                Console.WriteLine();
                Console.WriteLine();
            }
            //Console.ReadLine();
        }
    }
}
