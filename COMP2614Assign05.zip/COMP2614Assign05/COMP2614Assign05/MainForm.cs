﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace COMP2614Assign05
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void DateValidator_Load(object sender, EventArgs e)
        {
            labelValidator.Text = string.Empty;
        }

        private void buttonCheckDate_Click(object sender, EventArgs e)
        {
            int year, month, day;
           
            if (int.TryParse(textBoxYear.Text, out year) && int.TryParse(textBoxMonth.Text, out month) && int.TryParse(textBoxDay.Text, out day))
            // checks if the inputs are integer
            {
                if (DateValidator.Validate(year, month, day))
                {
                    displayValid();
                }
                else
                {
                    displayInvalid();
                }
            }
            else 
            {
                displayInvalid();
            }
        }

        private void displayValid()
        {
            labelValidator.ForeColor = Color.Green;
            labelValidator.Text = "Valid";
            toolTipValid.SetToolTip(labelValidator, "Entered Date is Vaild");
        }

        private void displayInvalid()
        {
            labelValidator.ForeColor = Color.Red;
            labelValidator.Text = "Invalid";
            toolTipValid.SetToolTip(labelValidator, "Entered Date is NOT Vaild");
        }

        private void textBoxYear_Enter(object sender, EventArgs e)
        {
            textBoxYear.SelectAll();
        }

        private void textBoxMonth_Enter(object sender, EventArgs e)
        {
            textBoxMonth.SelectAll();
        }

        private void textBoxDay_Enter(object sender, EventArgs e)
        {
            textBoxDay.SelectAll();
        }

        
    }
}
