﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP2614Assign05
{
    /// <summary>
    /// Validates if a date is valid
    /// </summary>
    class DateValidator
    {
        /// <summary>
        /// Validates if a date is valid
        /// </summary>
        /// <param name="year">to hold year as int</param>
        /// <param name="month">to hold month as int</param>
        /// <param name="day">to hold day as int</param>
        /// <returns></returns>
        public static bool Validate(int year, int month, int day)
        {
            string fullDay = year.ToString() + " " + month.ToString() + " " + day.ToString();
            DateTime date;
            if (year >= 1900 && month > 0 && day > 0 && DateTime.TryParse(fullDay, out date))
            {
                return true;
            }
            return false;
        }
    }
}
