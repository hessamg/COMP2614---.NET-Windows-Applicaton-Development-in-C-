﻿// Assignment 4 Solution
// Hessam Ganjian
// 25 Oct 2017
// Program.cs


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

/// <summary>
/// This program queries a table on a remote SQL Server, process and display the data in a formatted manner.
/// </summary>
namespace COMP2614Assign04
{
    class Program
    {
        static void Main(string[] args)
        {
            ConsolePrinter.PrintChoices();
            int choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1:
                    Console.WriteLine($"Customer listing for AB");

                    try
                    {
                        CustomerCollection customers = CustomerRepository.GetAllCustomersbyProvince("AB");
                        ConsolePrinter.PrintCollection(customers);
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Data Access Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine($"Processing Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }

                    break;

                case 2:
                    Console.WriteLine($"Customer listing for BC");

                    try
                    {
                        CustomerCollection customers = CustomerRepository.GetAllCustomersbyProvince("BC");
                        ConsolePrinter.PrintCollection(customers);
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Data Access Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine($"Processing Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }

                    break;

                case 3:
                    Console.WriteLine($"Customer listing for ON");

                    try
                    {
                        CustomerCollection customers = CustomerRepository.GetAllCustomersbyProvince("ON");
                        ConsolePrinter.PrintCollection(customers);
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Data Access Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine($"Processing Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }

                    break;

                case 4:
                    Console.WriteLine($"Customer listing for SK");

                    try
                    {
                        CustomerCollection customers = CustomerRepository.GetAllCustomersbyProvince("SK");
                        ConsolePrinter.PrintCollection(customers);
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Data Access Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine($"Processing Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }

                    break;

                case 5:
                    Console.WriteLine($"Customer listing for ALL");

                    try
                    {
                        CustomerCollection customers = CustomerRepository.GetAllCustomers();
                        ConsolePrinter.PrintCollection(customers);
                    }
                    catch (SqlException ex)
                    {
                        Console.WriteLine($"Data Access Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }

                    catch (Exception ex)
                    {
                        Console.WriteLine($"Processing Error\n\n{ex.Message}\n\n{ex.StackTrace}");
                    }
                    break;

                default:
                    Console.WriteLine($"{choice} is not an option. Program Terminated!!!");
                    break;
            }
        }
    }
}
