﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Custorms information
/// </summary>

namespace COMP2614Assign04
{
    class Customer : IComparable<Customer>
    {
        private string companyName;
        private string address;
        private string city;
        private string province;
        private string postalCode;
        private bool isCreditHold;

        /// <summary>
        /// ctor
        /// </summary>
        /// <param name="companyName">to hold company name</param>
        /// <param name="address">to hold address</param>
        /// <param name="city">to hold city</param>
        /// <param name="province">to hold province</param>
        /// <param name="postalCode">to hold postal code</param>
        /// <param name="isCreditHold">to check if credit is on hold</param>
        public Customer(string companyName, string address, string city, string province, string postalCode, bool isCreditHold)
        {
            this.companyName = companyName;
            this.address = address;
            this.city = city;
            this.province = province;
            this.postalCode = postalCode;
            this.isCreditHold = isCreditHold;
        }

        /// <summary>
        /// CompanyName preperty method
        /// </summary>
        public string CompanyName
        {
            get { return companyName; }
            set { companyName = value; }
        }

        /// <summary>
        /// Address preperty method
        /// </summary>
        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        /// <summary>
        /// City preperty method
        /// </summary>
        public string City
        {
            get { return city; }
            set { city = value; }
        }

        /// <summary>
        /// Province preperty method
        /// </summary>
        public string Province
        {
            get { return province; }
            set { province = value; }
        }

        /// <summary>
        /// PostalCode preperty method
        /// </summary>
        public string PostalCode
        {
            get { return postalCode; }
            set { postalCode = value; }
        }

        /// <summary>
        /// IsCreditHold preperty method
        /// </summary>
        public bool IsCreditHold
        {
            get { return isCreditHold; }
            set { isCreditHold = value; }
        }

        /// <summary>
        /// To compare with another customer
        /// </summary>
        /// <param name="other">to hold the other customer</param>
        /// <returns></returns>
        public int CompareTo(Customer other) // implementing IComparable<> forces 
        {                                  // the implementation of this method 
            if (other == null)
            {
                return 1; // if other object is null, this object is determined to be greater
            }             // returning here also prevents a null-reference exception accessing     
                          // other's properties below
            int result = this.Province.CompareTo(other.Province);   // use Description as sort field

            return -result; // returns -1: this object <  other object
        }
    }
}
