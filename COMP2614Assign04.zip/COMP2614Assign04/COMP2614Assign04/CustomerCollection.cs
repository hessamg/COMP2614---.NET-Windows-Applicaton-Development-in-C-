﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// this class is a list of Customers
/// </summary>
namespace COMP2614Assign04
{
    class CustomerCollection: List<Customer>
    {

    }
}
