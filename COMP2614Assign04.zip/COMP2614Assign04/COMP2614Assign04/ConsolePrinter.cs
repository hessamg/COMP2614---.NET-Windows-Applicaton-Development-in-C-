﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// ConsolePrinter.cs
/// Displays the data from the collection to the console
/// </summary>
namespace COMP2614Assign04
{
    class ConsolePrinter
    {
        public static void PrintChoices()
        {
            Console.WriteLine($"Select province filter:");
            Console.WriteLine($"{"",10}1: AB");
            Console.WriteLine($"{"",10}2: BC");
            Console.WriteLine($"{"",10}3: ON");
            Console.WriteLine($"{"",10}4: SK");
            Console.WriteLine($"{"",10}5: ALL");
        }

        public static void PrintCollection(CustomerCollection customers)
        {
            Console.WriteLine();
            Console.WriteLine($"{"CompanyName",-35}{"City",-10}{"Prov",12}{"",1}{"Postal"}{"",2}{"Hold"}");
            Console.WriteLine(new string('-', 70));

            foreach (Customer customer in customers)
            {
                Console.Write($"{customer.CompanyName,-35}{customer.City,-10}{customer.Province,10}{"",3}{customer.PostalCode,7}{"",2}");
                if (customer.IsCreditHold)
                {
                    Console.WriteLine($"Y");
                }
                else
                {
                    Console.WriteLine($"N");
                }
            }
            Console.WriteLine();
        }
    }
}
