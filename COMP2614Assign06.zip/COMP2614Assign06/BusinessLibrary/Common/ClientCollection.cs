﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// A list of Client
/// </summary>
namespace BusinessLibrary.Common
{
    public class ClientCollection : BindingList<Client>
    {
        /// <summary>
        /// returns the sum of Year to Date Sales
        /// </summary>
        public decimal TotalYTDSales => this.Sum(x => x.YTDSales);

        /// <summary>
        /// returns the total number of credit holds
        /// </summary>
        public int CreditHoldCount => this.Count(x => x.CreditHold == true);
        
    }
}
