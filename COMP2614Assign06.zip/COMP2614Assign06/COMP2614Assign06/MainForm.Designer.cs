﻿namespace COMP2614Assign06
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.buttonEditRecord = new System.Windows.Forms.Button();
            this.dataGridViewClients = new System.Windows.Forms.DataGridView();
            this.labelTotalYTDSales = new System.Windows.Forms.Label();
            this.labelCreditHoldCount = new System.Windows.Forms.Label();
            this.labelTotalYTDSalesResult = new System.Windows.Forms.Label();
            this.labelCreditHoldCountResult = new System.Windows.Forms.Label();
            this.buttonDelete = new System.Windows.Forms.Button();
            this.buttonNewClient = new System.Windows.Forms.Button();
            this.checkBoxShowDeleteMessage = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonEditRecord
            // 
            this.buttonEditRecord.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonEditRecord.Location = new System.Drawing.Point(1046, 615);
            this.buttonEditRecord.Name = "buttonEditRecord";
            this.buttonEditRecord.Size = new System.Drawing.Size(75, 23);
            this.buttonEditRecord.TabIndex = 5;
            this.buttonEditRecord.Text = "&Edit Record";
            this.buttonEditRecord.UseVisualStyleBackColor = true;
            this.buttonEditRecord.Click += new System.EventHandler(this.buttonEditRecord_Click);
            // 
            // dataGridViewClients
            // 
            this.dataGridViewClients.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewClients.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewClients.Location = new System.Drawing.Point(12, 21);
            this.dataGridViewClients.Name = "dataGridViewClients";
            this.dataGridViewClients.Size = new System.Drawing.Size(1109, 512);
            this.dataGridViewClients.TabIndex = 0;
            this.dataGridViewClients.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewClients_CellClick);
            this.dataGridViewClients.DoubleClick += new System.EventHandler(this.buttonEditRecord_Click);
            // 
            // labelTotalYTDSales
            // 
            this.labelTotalYTDSales.AutoSize = true;
            this.labelTotalYTDSales.Location = new System.Drawing.Point(41, 569);
            this.labelTotalYTDSales.Name = "labelTotalYTDSales";
            this.labelTotalYTDSales.Size = new System.Drawing.Size(130, 13);
            this.labelTotalYTDSales.TabIndex = 1;
            this.labelTotalYTDSales.Text = "&Total Year To Date Sales:";
            // 
            // labelCreditHoldCount
            // 
            this.labelCreditHoldCount.AutoSize = true;
            this.labelCreditHoldCount.Location = new System.Drawing.Point(41, 600);
            this.labelCreditHoldCount.Name = "labelCreditHoldCount";
            this.labelCreditHoldCount.Size = new System.Drawing.Size(93, 13);
            this.labelCreditHoldCount.TabIndex = 3;
            this.labelCreditHoldCount.Text = "&Credit Hold Count:";
            // 
            // labelTotalYTDSalesResult
            // 
            this.labelTotalYTDSalesResult.AutoSize = true;
            this.labelTotalYTDSalesResult.Location = new System.Drawing.Point(177, 569);
            this.labelTotalYTDSalesResult.Name = "labelTotalYTDSalesResult";
            this.labelTotalYTDSalesResult.Size = new System.Drawing.Size(139, 13);
            this.labelTotalYTDSalesResult.TabIndex = 1;
            this.labelTotalYTDSalesResult.Text = "<Total Year To Date Sales>";
            // 
            // labelCreditHoldCountResult
            // 
            this.labelCreditHoldCountResult.AutoSize = true;
            this.labelCreditHoldCountResult.Location = new System.Drawing.Point(177, 600);
            this.labelCreditHoldCountResult.Name = "labelCreditHoldCountResult";
            this.labelCreditHoldCountResult.Size = new System.Drawing.Size(102, 13);
            this.labelCreditHoldCountResult.TabIndex = 3;
            this.labelCreditHoldCountResult.Text = "<Credit Hold Count>";
            // 
            // buttonDelete
            // 
            this.buttonDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDelete.Location = new System.Drawing.Point(881, 615);
            this.buttonDelete.Name = "buttonDelete";
            this.buttonDelete.Size = new System.Drawing.Size(75, 23);
            this.buttonDelete.TabIndex = 19;
            this.buttonDelete.Text = "&Delete";
            this.buttonDelete.UseVisualStyleBackColor = true;
            this.buttonDelete.Click += new System.EventHandler(this.buttonDelete_Click);
            // 
            // buttonNewClient
            // 
            this.buttonNewClient.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonNewClient.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonNewClient.Location = new System.Drawing.Point(965, 615);
            this.buttonNewClient.Name = "buttonNewClient";
            this.buttonNewClient.Size = new System.Drawing.Size(75, 23);
            this.buttonNewClient.TabIndex = 18;
            this.buttonNewClient.Text = "&New Client";
            this.buttonNewClient.UseVisualStyleBackColor = true;
            this.buttonNewClient.Click += new System.EventHandler(this.buttonNewClient_Click);
            // 
            // checkBoxShowDeleteMessage
            // 
            this.checkBoxShowDeleteMessage.AutoSize = true;
            this.checkBoxShowDeleteMessage.Checked = true;
            this.checkBoxShowDeleteMessage.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxShowDeleteMessage.Location = new System.Drawing.Point(881, 565);
            this.checkBoxShowDeleteMessage.Name = "checkBoxShowDeleteMessage";
            this.checkBoxShowDeleteMessage.Size = new System.Drawing.Size(133, 17);
            this.checkBoxShowDeleteMessage.TabIndex = 20;
            this.checkBoxShowDeleteMessage.Text = "&Show Delete Message";
            this.checkBoxShowDeleteMessage.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AcceptButton = this.buttonEditRecord;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1133, 650);
            this.Controls.Add(this.checkBoxShowDeleteMessage);
            this.Controls.Add(this.labelCreditHoldCountResult);
            this.Controls.Add(this.labelCreditHoldCount);
            this.Controls.Add(this.labelTotalYTDSalesResult);
            this.Controls.Add(this.labelTotalYTDSales);
            this.Controls.Add(this.dataGridViewClients);
            this.Controls.Add(this.buttonEditRecord);
            this.Controls.Add(this.buttonDelete);
            this.Controls.Add(this.buttonNewClient);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Client Data";
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewClients)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonEditRecord;
        private System.Windows.Forms.DataGridView dataGridViewClients;
        private System.Windows.Forms.Label labelTotalYTDSales;
        private System.Windows.Forms.Label labelCreditHoldCount;
        private System.Windows.Forms.Label labelTotalYTDSalesResult;
        private System.Windows.Forms.Label labelCreditHoldCountResult;
        private System.Windows.Forms.Button buttonDelete;
        private System.Windows.Forms.Button buttonNewClient;
        private System.Windows.Forms.CheckBox checkBoxShowDeleteMessage;
    }
}

