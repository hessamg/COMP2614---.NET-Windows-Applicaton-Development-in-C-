﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BusinessLibrary.Business;
using BusinessLibrary.Common;
using System.Data.SqlClient;

namespace COMP2614Assign06
{
    partial class NewClientDialog : Form
    {
        public ClientViewModel clientVM { get; set; }

        public NewClientDialog()
        {
            InitializeComponent();
        }

        private void NewClientDialog_Load(object sender, EventArgs e)
        {       
            maskedTextBoxClientCode.Select();
            maskedTextBoxClientCode.SelectAll();
            setBindings();
        }

        private void setBindings()
        {
            maskedTextBoxClientCode.DataBindings.Add("Text", clientVM, "ClientCode", false, DataSourceUpdateMode.OnValidation, "");
            textBoxCompanyName.DataBindings.Add("Text", clientVM, "CompanyName", false, DataSourceUpdateMode.OnValidation, "");
            textBoxAddress1.DataBindings.Add("Text", clientVM, "Address1", false, DataSourceUpdateMode.OnValidation, "");
            textBoxAddress2.DataBindings.Add("Text", clientVM, "Address2", false, DataSourceUpdateMode.OnValidation, "");
            textBoxCity.DataBindings.Add("Text", clientVM, "City", false, DataSourceUpdateMode.OnValidation, "");
            maskedTextBoxProvince.DataBindings.Add("Text", clientVM, "Province", false, DataSourceUpdateMode.OnValidation, "");
            maskedTextBoxPostalCode.DataBindings.Add("Text", clientVM, "PostalCode", false, DataSourceUpdateMode.OnValidation, "");
            textBoxYTDSales.DataBindings.Add("Text", clientVM, "YTDSales", true, DataSourceUpdateMode.OnValidation, "0.00", "#,##0.00;(#,##0.00);0.00");
            checkBoxCreditHold.DataBindings.Add("Checked", clientVM, "CreditHold");
            textBoxNotes.DataBindings.Add("Text", clientVM, "Notes", false, DataSourceUpdateMode.OnValidation, "");

        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            try
            {
                Client client = clientVM.GetDisplayClient();
                int rowsAffected;
                bool duplicatePrimaryKey = false;
                string errorMessage;

                //check for Client Code uniquness 
                for (int i = 0; i < ClientValidation.GetClients().Count; i++)
                {
                    if (client.ClientCode == $"{ClientValidation.GetClients()[i].ClientCode}")
                    {
                        duplicatePrimaryKey = true;
                        i = ClientValidation.GetClients().Count;
                    }
                }
                if (duplicatePrimaryKey)
                {
                    rowsAffected = ClientValidation.UpdateClient(client);
                }
                else
                {
                    rowsAffected = ClientValidation.AddClient(client);
                }
                errorProviderNewClientDialog.SetError(buttonOk, ""); // clear errors 
                if (rowsAffected > 0)
                {
                    this.DialogResult = DialogResult.OK;
                }
                else
                {
                    if (rowsAffected == 0)
                    {
                        errorMessage = "No DB changes were made";
                    }
                    else
                    {
                        errorMessage = ClientValidation.ErrorMessage;
                    }

                    errorProviderNewClientDialog.SetError(buttonOk, errorMessage);
                }

            }

            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message, "DB Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Processing Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
